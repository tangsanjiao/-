// index.js
// 获取应用实例
const app = getApp()

var rand,sum;
function createrand(){
  rand=[];
  for(var i=0;i<7;i++){
    var r=parseInt(Math.random()*31+1);
    rand.push(r);
    console.log(rand[i]); 
  }

}


Page({
  onLoad: function() {
    createrand(); //调用产生随机数函数
    this.setData({
      rand: rand
    })
  },
  newRand: function() {
    createrand(); //调用产生随机数函数
    this.setData({
      rand: rand
    })
  }
})
