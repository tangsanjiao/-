// index.js
// 获取应用实例
const app = getApp()

var start,end,sum;
Page({
  startnum:function(e){
    start=e.detail.value;
  },
  endnum:function(e){
    end=parseFloat(e.detail.value);
  },
  calc:function(){
    sum=1000;
    for(var i=1;i<=5;i++){
      sum=sum*(1+end);
    }
    this.setData({
      sum:sum
    })
  }
})

