// pages/sankong/index4.js
Page({
  data: {
    imgsrc:"https://www.sdta.cn/uploads/indeximage/3.jpg"
  }

})