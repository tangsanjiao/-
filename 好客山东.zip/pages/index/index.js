// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    imgsrc:"https://bkimg.cdn.bcebos.com/pic/a5c27d1ed21b0ef48b91ec01dec451da81cb3e77?x-bce-process=image/watermark,image_d2F0ZXIvYmFpa2U5Mg==,g_7,xp_5,yp_5/format,f_auto"
  }

})
