// pages/matahu/index3.js
Page({
  data: {
    imgsrc:"https://bkimg.cdn.bcebos.com/pic/b17eca8065380cd7ad55b15fa644ad345982813c?x-bce-process=image/watermark,image_d2F0ZXIvYmFpa2UxNTA=,g_7,xp_5,yp_5/format,f_auto"
  }

})