// pages/quancheng/index2.js
Page({
  data: {
    imgsrc:"https://res.sdta.cn/uploads/1492746746/1492746829-1492746829.jpg"
  }

})