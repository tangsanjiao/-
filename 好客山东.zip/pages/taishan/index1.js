// pages/taishan/index1.js
Page({
  data: {
    imgsrc:"https://www.sdta.cn/uploads/indeximage/1.jpg"
  }

})